export interface ChatMessage {
  author: string;
  message: string;
}
