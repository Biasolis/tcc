export default interface IFindAllUsersContactsDTO {
  user_id: string;
}
