export default {
  jwt: {
    secret: 'doklxcjn834rhu8934ndiqewdh78u23',
    expiresIn: '1d',
  },
};
